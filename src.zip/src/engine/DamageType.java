package engine;

public enum DamageType {
    PHYSICAL, MAGIC, TRUE_DAMAMGE;
}
