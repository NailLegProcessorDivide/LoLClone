package LeagueBits;

import org.joml.Vector2f;

public interface IWorldObject {
    Vector2f getPossition();
}
